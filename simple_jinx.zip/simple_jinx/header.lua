return {
    id = 'SimpleJinx';
    name = 'Simple Jinx';
    load = function()
     	return player.charName == "Jinx"
    end;
}