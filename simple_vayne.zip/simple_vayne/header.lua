return {
    id = 'SimpleVayne';
    name = 'Simple Vayne';
    load = function()
     	return player.charName == "Vayne"
    end;
    type = "Champion";
}