return {
    id = 'SimpleVi';
    name = 'Simple Vi';
    riot = true;
    load = function()
     	return player.charName == "Vi"
    end;
}