return {
    id = 'SimpleVi';
    name = 'Simple Vi';
    load = function()
     	return player.charName == "Vi"
    end;
}